# AI Video Studio Pro V4 — Production-oriented Netlify build

## What it does
- 1 product -> up to 3 different sales clips
- Gemini creates hooks, Thai voiceover scripts and visual prompts
- Veo 3.1 creates 9:16 720p clips
- Job state is persisted in Netlify Blobs rather than an in-memory Map
- Generated video is served through a download function
- API keys stay in Netlify Functions

## Deploy
1. Upload this repository to GitHub.
2. Import the repo into your Netlify team/project.
3. Build command: optional/empty. Publish directory: `public`. Functions: `netlify/functions`.
4. Add environment variables in Netlify UI:
   GEMINI_API_KEY = your Gemini API key
   VEO_MODEL = veo-3.1-generate-preview
5. Scope the key to Functions if your Netlify plan supports scopes.
6. Redeploy after changing variables.

## Important
Veo 3.1 currently generates 8-second clips and supports portrait 9:16, 720p/1080p/4K and native audio. This V4 deliberately uses 720p 9:16 for a cheaper/faster social-video workflow.
Netlify synchronous functions have a 60-second limit, so the app starts Veo asynchronously and the browser polls the job endpoint. For a production scale-up, use a background function/queue for orchestration and add auth/rate limits/billing.

## Security
Never put GEMINI_API_KEY in `public/` or browser JavaScript. Netlify documents environment variables for Functions as the secure place for API keys.
